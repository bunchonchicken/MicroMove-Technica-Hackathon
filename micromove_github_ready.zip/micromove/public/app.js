let currentPlan = null;
let chart = null;
const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat("en-US", {style:"currency",currency:"USD"}).format(Number(n || 0));
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}
function setStatus(message) { $("status").textContent = message; }

function render(plan) {
  currentPlan = plan;
  const m = plan.metrics;
  $("balance").textContent = money(plan.account.balance);
  $("safe").textContent = money(m.safeToSetAside);
  $("save").textContent = money(m.suggestedSave);
  $("bills").textContent = money(m.upcomingBills14d);
  $("recTitle").textContent = plan.recommendation.title;
  $("recDetail").textContent = plan.recommendation.detail;
  $("destination").textContent = plan.recommendation.destination;
  $("recReason").textContent = plan.recommendation.reason;
  $("weekly").textContent = money(m.suggestedSave * 7);
  $("monthly").textContent = money(m.suggestedSave * 30);
  $("yearly").textContent = money(m.suggestedSave * 365);
  const bills = plan.upcomingBills || [];
  $("billCount").textContent = `${bills.length} item${bills.length === 1 ? "" : "s"}`;
  $("billList").innerHTML = bills.length ? bills.map(b => `
    <div class="bill-row">
      <div class="bill-left"><div class="bill-icon">▤</div><div><div class="bill-name">${escapeHtml(b.name)}</div><div class="bill-date">Due ${escapeHtml(b.date)}</div></div></div>
      <div class="bill-amount">${money(b.amount)}</div>
    </div>`).join("") : `<div class="empty-state">No unpaid bills due in the next 14 days were found in the available records.</div>`;
  drawChart(plan);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
function drawChart(plan) {
  if (typeof Chart === "undefined") return;
  const m = plan.metrics;
  const ctx = $("forecastChart").getContext("2d");
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Current balance", "Bills + buffer", "After saving"],
      datasets: [{data: [plan.account.balance, m.upcomingBills14d + m.spendingBuffer, m.projectedBalanceAfterSave], backgroundColor:["#143e3e","#e4b65a","#168c79"], borderRadius:7, borderSkipped:false, maxBarThickness:48}]
    },
    options: {responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>money(c.raw)}}},scales:{x:{grid:{display:false},ticks:{color:"#6e8187",font:{size:10}},border:{display:false}},y:{beginAtZero:true,grid:{color:"#edf1f2"},ticks:{color:"#6e8187",font:{size:10},callback:v=>"$"+v},border:{display:false}}}}
  });
}
async function loadDemo() {
  setStatus("Loading illustrative demo data…");
  try {
    const r = await fetch("/api/demo-plan");
    if (!r.ok) throw new Error("Could not load demo data.");
    render(await r.json());
    setStatus("Demo mode: all figures are fictional and illustrative.");
  } catch (e) { setStatus(e.message); }
}
async function loadAccount() {
  const id = $("accountId").value.trim();
  if (!id) { toast("Enter a Nessie account ID first."); return; }
  const goal = $("goal").value;
  setStatus("Loading account and transaction records from Nessie…");
  $("loadAccount").disabled = true;
  try {
    const r = await fetch(`/api/accounts/${encodeURIComponent(id)}/plan?goal=${encodeURIComponent(goal)}`);
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Could not load account.");
    render(data);
    setStatus("Connected to Nessie sandbox account. Review the available records and assumptions.");
  } catch (e) { setStatus(e.message); toast("Account load failed. Check the account ID and server API key."); }
  finally { $("loadAccount").disabled = false; }
}
$("demo").addEventListener("click", loadDemo);
$("loadAccount").addEventListener("click", loadAccount);
$("refresh").addEventListener("click", () => $("accountId").value.trim() ? loadAccount() : loadDemo());
$("goal").addEventListener("change", () => { if ($("accountId").value.trim()) loadAccount(); });
$("simulate").addEventListener("click", () => {
  if (!currentPlan) return;
  const amount = currentPlan.metrics.suggestedSave;
  if (amount <= 0) {
    toast("No savings suggested right now—protect bills and your buffer first.");
    return;
  }
  const after = currentPlan.account.balance - amount;
  toast(`Preview only: ${money(amount)} set aside; checking would be ${money(after)}. No transfer was made.`);
});
loadDemo();
