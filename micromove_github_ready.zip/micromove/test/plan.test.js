const test = require("node:test");
const assert = require("node:assert/strict");
const { buildPlan, dateOf, amountOf, isUnpaidBill, cents } = require("../lib/plan");

const dateOffset = days => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
};

const baseInput = overrides => ({
  account: { _id: "test-account", type: "Checking", balance: 200 },
  purchases: [], withdrawals: [], deposits: [], bills: [], goal: "emergency",
  ...overrides
});

test("returns a conservative savings suggestion when funds remain after the buffer", () => {
  const plan = buildPlan(baseInput({ account: { _id: "test-account", balance: 200 } }));
  assert.equal(plan.metrics.spendingBuffer, 50);
  assert.equal(plan.metrics.safeToSetAside, 150);
  assert.equal(plan.metrics.suggestedSave, 7.5);
  assert.equal(plan.recommendation.destination, "Emergency savings");
});

test("does not recommend savings when upcoming bills and buffer consume the balance", () => {
  const plan = buildPlan(baseInput({
    account: { _id: "test-account", balance: 100 },
    bills: [{ amount: 80, payment_date: dateOffset(2), status: "pending" }]
  }));
  assert.equal(plan.metrics.suggestedSave, 0);
  assert.equal(plan.recommendation.destination, "Checking buffer");
});

test("excludes paid bills and includes unpaid bills due within 14 days", () => {
  const plan = buildPlan(baseInput({
    account: { _id: "test-account", balance: 500 },
    bills: [
      { amount: 25, payment_date: dateOffset(3), status: "paid" },
      { amount: 40, payment_date: dateOffset(4), status: "pending", payee: "Phone" },
      { amount: 60, payment_date: dateOffset(20), status: "pending" }
    ]
  }));
  assert.equal(plan.metrics.upcomingBills14d, 40);
  assert.equal(plan.upcomingBills.length, 1);
  assert.equal(plan.upcomingBills[0].name, "Phone");
});

test("supports debt and personal-goal priorities when cash flow is safe", () => {
  const debt = buildPlan(baseInput({ account: { _id: "a", balance: 500 }, goal: "debt" }));
  const goal = buildPlan(baseInput({ account: { _id: "a", balance: 500 }, goal: "goal" }));
  assert.equal(debt.recommendation.destination, "Debt payoff");
  assert.equal(goal.recommendation.destination, "Personal savings goal");
});

test("normalizes invalid transaction amounts and recognizes bill status case-insensitively", () => {
  assert.equal(amountOf({ amount: "not-a-number" }), 0);
  assert.equal(amountOf({ amount: -4.25 }), 4.25);
  assert.equal(isUnpaidBill({ status: "PAID" }), false);
  assert.equal(isUnpaidBill({ status: "pending" }), true);
});

test("handles missing dates and rounds to cents", () => {
  assert.equal(dateOf({}), null);
  assert.equal(cents(1.005), 1.01);
});

test("rejects account data without a valid balance", () => {
  assert.throws(() => buildPlan(baseInput({ account: { _id: "bad", balance: "unknown" } })), /valid balance/);
});
